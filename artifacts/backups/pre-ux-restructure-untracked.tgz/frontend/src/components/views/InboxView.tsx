"use client";

import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Bell,
  Bookmark,
  Clock3,
  ExternalLink,
  EyeOff,
  FilePenLine,
  RefreshCw,
  Send,
} from "lucide-react";

import { useInbox } from "@/hooks/useInbox";
import { useTheses } from "@/hooks/useTheses";
import { postAPI } from "@/lib/api";
import type { InboxItem } from "@/types";
import { useView } from "@/contexts/ViewContext";

const FILTERS = [
  { label: "Portfolio", patch: { scope: "portfolio" } },
  { label: "Watchlist", patch: { scope: "watchlist" } },
  { label: "Macro", patch: { scope: "macro" } },
  { label: "Research", patch: { scope: "research" } },
  { label: "Saved", patch: { status: "saved" } },
  { label: "Dismissed", patch: { status: "dismissed" } },
  { label: "Confirmed", patch: { status: "confirmed" } },
  { label: "Exploratory", patch: { status: "exploratory" } },
];

function badgeTone(item: InboxItem) {
  if (item.state === "confirmed") {
    return "border-oracle-green/30 bg-oracle-green/10 text-oracle-green";
  }
  return "border-oracle-yellow/30 bg-oracle-yellow/10 text-oracle-yellow";
}

function priorityTone(score: number) {
  if (score >= 75) return "text-oracle-red";
  if (score >= 55) return "text-oracle-yellow";
  return "text-oracle-accent";
}

function timeAgo(value: string) {
  const diff = Date.now() - new Date(value).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "ahora";
  if (mins < 60) return `hace ${mins}m`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `hace ${hours}h`;
  return `hace ${Math.floor(hours / 24)}d`;
}

export default function InboxView() {
  const { data, loading, error, filters, setFilters, refresh, mutateItem, reload } = useInbox();
  const { createFromInbox } = useTheses();
  const { setActiveView, setSelectedSymbol } = useView();
  const [selectedId, setSelectedId] = useState<string>("");
  const [creatingAlert, setCreatingAlert] = useState(false);

  useEffect(() => {
    if (data?.items[0] && !selectedId) {
      setSelectedId(data.items[0].id);
    }
    if (selectedId && data && !data.items.some((item) => item.id === selectedId)) {
      setSelectedId(data.items[0]?.id ?? "");
    }
  }, [data, selectedId]);

  const selectedItem = useMemo(
    () => data?.items.find((item) => item.id === selectedId) ?? data?.items[0] ?? null,
    [data, selectedId]
  );

  const handleCreateAlert = async (item: InboxItem) => {
    if (!item.primary_symbol) return;
    try {
      setCreatingAlert(true);
      await postAPI("/api/v1/alerts/rules", {
        name: `${item.primary_symbol} ${item.kind} monitor`,
        symbols: [item.primary_symbol],
        cooldown_minutes: 120,
        delivery_channels: ["telegram"],
        active: true,
        linked_thesis_id: item.linked_thesis_id,
        conditions: [
          {
            field: "symbol",
            operator: "contains",
            value: item.primary_symbol,
            source: "inbox",
          },
        ],
      });
    } finally {
      setCreatingAlert(false);
    }
  };

  return (
    <div className="space-y-4">
      <section className="oracle-hero-surface rounded-2xl border border-oracle-border p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <span className="rounded-full border border-oracle-accent/30 bg-oracle-accent/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.28em] text-oracle-accent">
              Decision Inbox
            </span>
            <h2 className="mt-3 text-2xl font-semibold text-oracle-text">Lo importante ahora</h2>
            <p className="mt-1 max-w-3xl text-sm text-oracle-muted">
              Ranking unificado de riesgo, noticias, eventos, filings y oportunidades. <span className="font-mono text-oracle-text">Terminal</span> sigue siendo el zoom; aquí decides qué merece atención.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="rounded-xl border border-oracle-border bg-oracle-bg/60 px-4 py-3 text-sm">
              <p className="text-oracle-muted">Items activos</p>
              <p className="mt-1 text-lg font-semibold text-oracle-text">{data?.total ?? 0}</p>
            </div>
            <button
              onClick={() => refresh()}
              className="inline-flex items-center gap-2 rounded-xl border border-oracle-accent/30 bg-oracle-accent/15 px-4 py-3 text-sm font-medium text-oracle-accent transition-colors hover:bg-oracle-accent/25"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => setFilters({})}
            className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
              Object.keys(filters).length === 0
                ? "border-oracle-accent/40 bg-oracle-accent/20 text-oracle-accent"
                : "border-oracle-border text-oracle-muted hover:text-oracle-text"
            }`}
          >
            Todo
          </button>
          {FILTERS.map((filter) => {
            const active = Object.entries(filter.patch).every(
              ([key, value]) => filters[key as keyof typeof filters] === value
            );
            return (
              <button
                key={filter.label}
                onClick={() => setFilters(filter.patch)}
                className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                  active
                    ? "border-oracle-accent/40 bg-oracle-accent/20 text-oracle-accent"
                    : "border-oracle-border text-oracle-muted hover:text-oracle-text"
                }`}
              >
                {filter.label}
              </button>
            );
          })}
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[0.92fr_1.08fr]">
        <section className="rounded-2xl border border-oracle-border bg-oracle-panel">
          <div className="flex items-center justify-between border-b border-oracle-border px-4 py-3">
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-oracle-muted">Queue</p>
              <p className="mt-1 text-sm text-oracle-muted">
                {data?.generated_at ? `Actualizado ${timeAgo(data.generated_at)}` : "Pendiente"}
              </p>
            </div>
            <button
              onClick={() => reload(filters, true)}
              className="rounded-lg border border-oracle-border px-2.5 py-1 text-xs text-oracle-muted transition-colors hover:text-oracle-text"
            >
              Rebuild
            </button>
          </div>

          <div className="max-h-[72vh] overflow-y-auto p-3">
            {loading && !data ? (
              <div className="space-y-3">
                {Array.from({ length: 6 }).map((_, index) => (
                  <div key={index} className="animate-pulse rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                    <div className="h-3 w-24 rounded bg-oracle-border" />
                    <div className="mt-3 h-4 w-2/3 rounded bg-oracle-border" />
                    <div className="mt-2 h-3 w-full rounded bg-oracle-border" />
                  </div>
                ))}
              </div>
            ) : null}

            {!loading && data?.items.length === 0 ? (
              <div className="rounded-xl border border-dashed border-oracle-border p-6 text-center">
                <p className="text-sm text-oracle-text">No hay items para este filtro.</p>
                <p className="mt-1 text-xs text-oracle-muted">
                  Si no tienes portfolio ni watchlist, la app debería caer a macro y oportunidades de mercado al refrescar.
                </p>
              </div>
            ) : null}

            <div className="space-y-3">
              {data?.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setSelectedId(item.id)}
                  className={`w-full rounded-xl border p-4 text-left transition-colors ${
                    selectedItem?.id === item.id
                      ? "border-oracle-accent/50 bg-oracle-accent/10"
                      : "border-oracle-border bg-oracle-bg/40 hover:bg-oracle-bg"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${badgeTone(item)}`}>
                      {item.state}
                    </span>
                    <span className="rounded-full border border-oracle-border px-2 py-0.5 text-[10px] uppercase tracking-wide text-oracle-muted">
                      {item.scope}
                    </span>
                    <span className={`ml-auto text-xs font-mono ${priorityTone(item.priority_score)}`}>
                      {item.priority_score.toFixed(0)}
                    </span>
                  </div>
                  <h3 className="mt-3 text-sm font-semibold text-oracle-text">{item.title}</h3>
                  <p className="mt-2 line-clamp-2 text-xs leading-5 text-oracle-muted">{item.summary}</p>
                  <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-oracle-muted">
                    {item.symbols.slice(0, 3).map((symbol) => (
                      <span key={`${item.id}-${symbol}`} className="rounded bg-oracle-accent/10 px-1.5 py-0.5 font-mono text-oracle-accent">
                        {symbol}
                      </span>
                    ))}
                    <span>{Math.round(item.confidence * 100)}% conf</span>
                    <span>{item.horizon}</span>
                    <span>{timeAgo(item.updated_at)}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-oracle-border bg-oracle-panel">
          <div className="border-b border-oracle-border px-4 py-3">
            <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-oracle-muted">Detail</p>
            <p className="mt-1 text-sm text-oracle-muted">Why now, evidence and next action.</p>
          </div>

          {selectedItem ? (
            <div className="space-y-5 p-5">
              <div className="flex flex-wrap items-start gap-3">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${badgeTone(selectedItem)}`}>
                      {selectedItem.state}
                    </span>
                    <span className="rounded-full border border-oracle-border px-2 py-0.5 text-[10px] uppercase tracking-wide text-oracle-muted">
                      {selectedItem.kind}
                    </span>
                  </div>
                  <h3 className="mt-3 text-xl font-semibold text-oracle-text">{selectedItem.title}</h3>
                  <p className="mt-2 max-w-3xl text-sm leading-6 text-oracle-muted">{selectedItem.summary}</p>
                </div>
                <div className="ml-auto rounded-2xl border border-oracle-border bg-oracle-bg/60 px-4 py-3">
                  <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Priority</p>
                  <p className={`mt-1 text-2xl font-semibold ${priorityTone(selectedItem.priority_score)}`}>
                    {selectedItem.priority_score.toFixed(0)}
                  </p>
                  <p className="text-xs text-oracle-muted">{Math.round(selectedItem.confidence * 100)}% confidence</p>
                </div>
              </div>

              <div className="grid gap-4 lg:grid-cols-2">
                <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                  <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Why Now</p>
                  <p className="mt-2 text-sm leading-6 text-oracle-text">{selectedItem.why_now || "Waiting for confirmation."}</p>
                </div>
                <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                  <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Context</p>
                  <div className="mt-2 flex flex-wrap gap-2 text-xs">
                    <span className="rounded-full border border-oracle-border px-2 py-1 text-oracle-text">
                      impact {selectedItem.impact}
                    </span>
                    <span className="rounded-full border border-oracle-border px-2 py-1 text-oracle-text">
                      horizon {selectedItem.horizon}
                    </span>
                    <span className="rounded-full border border-oracle-border px-2 py-1 text-oracle-text">
                      status {selectedItem.status}
                    </span>
                    <span className="rounded-full border border-oracle-border px-2 py-1 text-oracle-text">
                      mode {selectedItem.assistant_mode}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => mutateItem(selectedItem.id, "save")}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-border bg-oracle-bg/60 px-3 py-2 text-sm text-oracle-text transition-colors hover:bg-oracle-bg"
                >
                  <Bookmark className="h-4 w-4" />
                  Save
                </button>
                <button
                  onClick={() => mutateItem(selectedItem.id, "dismiss")}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-border bg-oracle-bg/60 px-3 py-2 text-sm text-oracle-text transition-colors hover:bg-oracle-bg"
                >
                  <EyeOff className="h-4 w-4" />
                  Dismiss
                </button>
                <button
                  onClick={() => mutateItem(selectedItem.id, "snooze")}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-border bg-oracle-bg/60 px-3 py-2 text-sm text-oracle-text transition-colors hover:bg-oracle-bg"
                >
                  <Clock3 className="h-4 w-4" />
                  Snooze
                </button>
                <button
                  onClick={async () => {
                    const result = await createFromInbox(selectedItem.id);
                    setActiveView("theses");
                    await reload(filters, true);
                    setSelectedSymbol(result.thesis.symbol);
                  }}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-accent/30 bg-oracle-accent/15 px-3 py-2 text-sm text-oracle-accent transition-colors hover:bg-oracle-accent/20"
                >
                  <FilePenLine className="h-4 w-4" />
                  Create Thesis
                </button>
                <button
                  onClick={() => handleCreateAlert(selectedItem)}
                  disabled={creatingAlert || !selectedItem.primary_symbol}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-border bg-oracle-bg/60 px-3 py-2 text-sm text-oracle-text transition-colors hover:bg-oracle-bg disabled:opacity-50"
                >
                  <Bell className="h-4 w-4" />
                  Create Alert
                </button>
                <button
                  onClick={() => {
                    if (selectedItem.primary_symbol) {
                      setSelectedSymbol(selectedItem.primary_symbol);
                    }
                    setActiveView("terminal");
                  }}
                  className="inline-flex items-center gap-2 rounded-lg border border-oracle-border bg-oracle-bg/60 px-3 py-2 text-sm text-oracle-text transition-colors hover:bg-oracle-bg"
                >
                  <Send className="h-4 w-4" />
                  Open in Terminal
                </button>
              </div>

              <div className="grid gap-4 xl:grid-cols-[1.1fr_0.9fr]">
                <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                  <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Evidence</p>
                  <div className="mt-3 space-y-3">
                    {selectedItem.evidence.map((evidence, index) => (
                      <div key={`${evidence.source}-${index}`} className="rounded-lg border border-oracle-border bg-oracle-panel/60 p-3">
                        <div className="flex items-center gap-2 text-[11px] uppercase tracking-wide text-oracle-muted">
                          <span>{evidence.category}</span>
                          <span>{evidence.source}</span>
                          <span className="ml-auto font-mono">{Math.round(evidence.confidence * 100)}%</span>
                        </div>
                        <p className="mt-2 text-sm leading-6 text-oracle-text">{evidence.summary}</p>
                        {evidence.url ? (
                          <a
                            href={evidence.url}
                            target="_blank"
                            rel="noreferrer"
                            className="mt-2 inline-flex items-center gap-1 text-xs text-oracle-accent"
                          >
                            Open source
                            <ExternalLink className="h-3.5 w-3.5" />
                          </a>
                        ) : null}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                    <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Source Balance</p>
                    <div className="mt-3 space-y-2">
                      {selectedItem.source_breakdown.map((source) => (
                        <div key={source.source} className="flex items-center justify-between rounded-lg border border-oracle-border bg-oracle-panel/60 px-3 py-2 text-sm">
                          <div>
                            <p className="font-medium text-oracle-text">{source.source}</p>
                            <p className="text-xs text-oracle-muted">{source.count} items</p>
                          </div>
                          <div className="text-right">
                            <p className="font-mono text-oracle-text">{(source.weight * 100).toFixed(0)}</p>
                            <p className="text-xs text-oracle-muted">{(source.confidence * 100).toFixed(0)} conf</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                    <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Symbols</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {selectedItem.symbols.map((symbol) => (
                        <button
                          key={`${selectedItem.id}-${symbol}`}
                          onClick={() => {
                            setSelectedSymbol(symbol);
                            setActiveView("terminal");
                          }}
                          className="rounded-full border border-oracle-accent/25 bg-oracle-accent/10 px-2.5 py-1 font-mono text-xs text-oracle-accent transition-colors hover:bg-oracle-accent/20"
                        >
                          {symbol}
                        </button>
                      ))}
                      {selectedItem.symbols.length === 0 ? (
                        <div className="flex items-center gap-2 text-sm text-oracle-muted">
                          <AlertTriangle className="h-4 w-4" />
                          Macro / portfolio-level item
                        </div>
                      ) : null}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-8 text-center text-sm text-oracle-muted">
              Selecciona un item del inbox para ver detalle y acciones.
            </div>
          )}
          {error ? <p className="px-5 pb-5 text-sm text-oracle-red">{error}</p> : null}
        </section>
      </div>
    </div>
  );
}
