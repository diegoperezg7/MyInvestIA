"use client";

import { useMemo, useState } from "react";
import { BarChart3, BookmarkPlus, Database, RefreshCw, Sigma } from "lucide-react";

import { useResearch } from "@/hooks/useResearch";
import { useView } from "@/contexts/ViewContext";

function factorColor(value: number) {
  if (value >= 70) return "text-oracle-green";
  if (value <= 40) return "text-oracle-red";
  return "text-oracle-yellow";
}

export default function ResearchView() {
  const { rankings, factors, snapshots, loading, error, selectedSymbol, setSelectedSymbol, loadRankings, saveScreen } = useResearch();
  const { setActiveView, setSelectedSymbol: setGlobalSymbol } = useView();
  const [screenName, setScreenName] = useState("Core Research");

  const topSymbols = useMemo(
    () => rankings?.rankings.slice(0, 8).map((entry) => entry.symbol) ?? [],
    [rankings]
  );

  return (
    <div className="space-y-4">
      <section className="oracle-hero-surface rounded-2xl border border-oracle-border p-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <span className="rounded-full border border-oracle-accent/30 bg-oracle-accent/10 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.28em] text-oracle-accent">
              Quant Lab
            </span>
            <h2 className="mt-3 text-2xl font-semibold text-oracle-text">Ranking y validación ligera</h2>
            <p className="mt-1 max-w-3xl text-sm text-oracle-muted">
              El universo por defecto sale de portfolio y watchlists. Aquí priorizas señales con factores fijos, guardas pantallas y acumulas snapshots para validación <span className="font-mono text-oracle-text">1W / 1M / 3M</span>.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => loadRankings(true)}
              className="inline-flex items-center gap-2 rounded-xl border border-oracle-accent/30 bg-oracle-accent/15 px-4 py-3 text-sm font-medium text-oracle-accent transition-colors hover:bg-oracle-accent/25"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
              Refresh + snapshot
            </button>
            <button
              onClick={async () => {
                await saveScreen({
                  name: screenName,
                  symbols: topSymbols,
                  notes: "Top ranked symbols from the current quant view.",
                });
              }}
              className="inline-flex items-center gap-2 rounded-xl border border-oracle-border bg-oracle-bg/60 px-4 py-3 text-sm text-oracle-text transition-colors hover:bg-oracle-bg"
            >
              <BookmarkPlus className="h-4 w-4" />
              Save screen
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap items-center gap-3">
          <input
            value={screenName}
            onChange={(event) => setScreenName(event.target.value)}
            className="w-full max-w-sm rounded-xl border border-oracle-border bg-oracle-bg/70 px-3 py-2 text-sm text-oracle-text placeholder:text-oracle-muted"
            placeholder="Nombre para guardar la pantalla"
          />
          <div className="rounded-xl border border-oracle-border bg-oracle-bg/60 px-4 py-3 text-sm">
            <p className="text-oracle-muted">Universe</p>
            <p className="mt-1 font-semibold text-oracle-text">{rankings?.universe.length ?? 0} símbolos</p>
          </div>
          <div className="rounded-xl border border-oracle-border bg-oracle-bg/60 px-4 py-3 text-sm">
            <p className="text-oracle-muted">Snapshots</p>
            <p className="mt-1 font-semibold text-oracle-text">{snapshots?.total ?? 0}</p>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[1fr_1fr]">
        <section className="rounded-2xl border border-oracle-border bg-oracle-panel">
          <div className="border-b border-oracle-border px-4 py-3">
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-oracle-muted">
              <Sigma className="h-3.5 w-3.5" />
              Rankings
            </div>
            <p className="mt-1 text-sm text-oracle-muted">
              Factores fijos: momentum, quality, value, revisions, sentiment, insider accumulation y risk.
            </p>
          </div>
          <div className="max-h-[72vh] overflow-y-auto p-3">
            <div className="space-y-3">
              {rankings?.rankings.map((entry) => (
                <button
                  key={entry.symbol}
                  onClick={() => setSelectedSymbol(entry.symbol)}
                  className={`w-full rounded-xl border p-4 text-left transition-colors ${
                    selectedSymbol === entry.symbol
                      ? "border-oracle-accent/50 bg-oracle-accent/10"
                      : "border-oracle-border bg-oracle-bg/40 hover:bg-oracle-bg"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <p className="text-lg font-semibold text-oracle-text">{entry.symbol}</p>
                    <span className="rounded-full border border-oracle-border px-2 py-0.5 text-[10px] uppercase tracking-wide text-oracle-muted">
                      {entry.verdict}
                    </span>
                    <span className="ml-auto text-sm font-mono text-oracle-accent">
                      {entry.composite_score.toFixed(1)}
                    </span>
                  </div>
                  <p className="mt-1 text-sm text-oracle-muted">{entry.name}</p>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
                    <div className="rounded-lg border border-oracle-border bg-oracle-panel/60 px-2 py-2">
                      <p className="text-oracle-muted">Momentum</p>
                      <p className={`mt-1 font-mono ${factorColor(entry.factors.momentum)}`}>{entry.factors.momentum.toFixed(0)}</p>
                    </div>
                    <div className="rounded-lg border border-oracle-border bg-oracle-panel/60 px-2 py-2">
                      <p className="text-oracle-muted">Sentiment</p>
                      <p className={`mt-1 font-mono ${factorColor(entry.factors.sentiment)}`}>{entry.factors.sentiment.toFixed(0)}</p>
                    </div>
                    <div className="rounded-lg border border-oracle-border bg-oracle-panel/60 px-2 py-2">
                      <p className="text-oracle-muted">Risk</p>
                      <p className={`mt-1 font-mono ${factorColor(entry.factors.risk)}`}>{entry.factors.risk.toFixed(0)}</p>
                    </div>
                  </div>
                </button>
              ))}
            </div>
            {loading && !rankings ? <p className="text-sm text-oracle-muted">Cargando rankings...</p> : null}
            {error ? <p className="text-sm text-oracle-red">{error}</p> : null}
          </div>
        </section>

        <section className="space-y-4">
          <div className="rounded-2xl border border-oracle-border bg-oracle-panel">
            <div className="border-b border-oracle-border px-4 py-3">
              <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-oracle-muted">
                <BarChart3 className="h-3.5 w-3.5" />
                Factor Detail
              </div>
              <p className="mt-1 text-sm text-oracle-muted">{selectedSymbol || "Selecciona un símbolo"}</p>
            </div>
            {factors ? (
              <div className="space-y-4 p-5">
                <div className="flex flex-wrap items-start gap-3">
                  <div>
                    <h3 className="text-xl font-semibold text-oracle-text">{factors.symbol}</h3>
                    <p className="mt-1 text-sm text-oracle-muted">
                      verdict {factors.verdict} · regime {factors.regime} · confidence {(factors.confidence * 100).toFixed(0)}%
                    </p>
                  </div>
                  <div className="ml-auto rounded-2xl border border-oracle-border bg-oracle-bg/60 px-4 py-3">
                    <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Composite</p>
                    <p className="mt-1 text-2xl font-semibold text-oracle-accent">
                      {factors.composite_score.toFixed(1)}
                    </p>
                  </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                  {Object.entries(factors.factors).map(([name, value]) => (
                    <div key={name} className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                      <p className="text-[11px] uppercase tracking-wide text-oracle-muted">{name}</p>
                      <p className={`mt-2 text-lg font-semibold ${factorColor(value)}`}>{value.toFixed(1)}</p>
                    </div>
                  ))}
                </div>

                <div className="grid gap-4 lg:grid-cols-2">
                  <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                    <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Risk metrics</p>
                    <div className="mt-3 space-y-2 text-sm text-oracle-text">
                      {Object.entries(factors.risk_metrics).map(([key, value]) => (
                        <div key={key} className="flex items-center justify-between">
                          <span className="text-oracle-muted">{key}</span>
                          <span className="font-mono">{typeof value === "number" ? value.toFixed(3) : String(value)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                    <p className="text-[11px] uppercase tracking-wide text-oracle-muted">Candlestick patterns</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {factors.candlestick_patterns.length > 0 ? factors.candlestick_patterns.map((pattern) => (
                        <span key={pattern} className="rounded-full border border-oracle-border px-2 py-1 text-xs text-oracle-text">
                          {pattern}
                        </span>
                      )) : <span className="text-sm text-oracle-muted">No dominant patterns</span>}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setGlobalSymbol(factors.symbol);
                    setActiveView("terminal");
                  }}
                  className="rounded-lg border border-oracle-accent/30 bg-oracle-accent/15 px-3 py-2 text-sm text-oracle-accent transition-colors hover:bg-oracle-accent/20"
                >
                  Open in Terminal
                </button>
              </div>
            ) : (
              <div className="p-6 text-sm text-oracle-muted">Selecciona un símbolo del ranking para ver factores.</div>
            )}
          </div>

          <div className="rounded-2xl border border-oracle-border bg-oracle-panel">
            <div className="border-b border-oracle-border px-4 py-3">
              <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-oracle-muted">
                <Database className="h-3.5 w-3.5" />
                Snapshots
              </div>
              <p className="mt-1 text-sm text-oracle-muted">Backtest lite basado en snapshots históricos.</p>
            </div>
            <div className="space-y-3 p-4">
              {(snapshots?.snapshots ?? []).slice(0, 4).map((snapshot) => (
                <div key={snapshot.id} className="rounded-xl border border-oracle-border bg-oracle-bg/50 p-4">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="font-medium text-oracle-text">{snapshot.name}</p>
                      <p className="text-xs text-oracle-muted">{snapshot.universe.length} símbolos · {new Date(snapshot.captured_at).toLocaleString()}</p>
                    </div>
                    <span className="text-xs font-mono text-oracle-muted">{snapshot.rankings.length} ranks</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {snapshot.validation.map((item) => (
                      <span key={`${snapshot.id}-${item.horizon}`} className="rounded-full border border-oracle-border px-2 py-1 text-xs text-oracle-text">
                        {item.horizon} avg {(item.average_return * 100).toFixed(1)}%
                      </span>
                    ))}
                  </div>
                </div>
              ))}
              {(snapshots?.snapshots ?? []).length === 0 ? (
                <p className="text-sm text-oracle-muted">Aún no hay snapshots guardados.</p>
              ) : null}
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
