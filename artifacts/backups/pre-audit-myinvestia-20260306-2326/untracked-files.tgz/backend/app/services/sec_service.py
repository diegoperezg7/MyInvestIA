"""SEC EDGAR filings helpers."""

from __future__ import annotations

import logging
from datetime import datetime, timezone

import httpx

from app.config import settings
from app.services.cache import get_or_fetch

logger = logging.getLogger(__name__)

SEC_TICKERS_URL = "https://www.sec.gov/files/company_tickers.json"
SEC_SUBMISSIONS_URL = "https://data.sec.gov/submissions/CIK{cik}.json"
SEC_TTL = 3600


def _default_headers() -> dict[str, str]:
    return {
        "User-Agent": settings.sec_user_agent,
        "Accept-Encoding": "gzip, deflate",
        "Host": "www.sec.gov",
    }


async def _get_company_map() -> dict[str, dict]:
    async def _fetch():
        try:
            async with httpx.AsyncClient(timeout=12.0, headers=_default_headers()) as client:
                response = await client.get(SEC_TICKERS_URL)
                response.raise_for_status()
                payload = response.json()
        except Exception as exc:
            logger.warning("SEC company map unavailable: %s", exc)
            return {}

        companies: dict[str, dict] = {}
        if isinstance(payload, dict):
            iterable = payload.values()
        else:
            iterable = payload

        for item in iterable:
            symbol = str(item.get("ticker") or "").upper().strip()
            if not symbol:
                continue
            companies[symbol] = {
                "symbol": symbol,
                "name": str(item.get("title") or symbol),
                "cik": str(item.get("cik_str") or "").zfill(10),
            }
        return companies

    return await get_or_fetch("sec:company-map", _fetch, 24 * SEC_TTL) or {}


async def lookup_company(symbol: str) -> dict | None:
    companies = await _get_company_map()
    return companies.get(symbol.upper())


async def get_company_filings(symbol: str, limit: int = 10) -> dict:
    symbol_upper = symbol.upper()
    company = await lookup_company(symbol_upper)
    if not company:
        return {
            "symbol": symbol_upper,
            "company_name": symbol_upper,
            "cik": "",
            "source": "sec",
            "filings": [],
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    async def _fetch():
        try:
            async with httpx.AsyncClient(timeout=15.0, headers=_default_headers()) as client:
                response = await client.get(SEC_SUBMISSIONS_URL.format(cik=company["cik"]))
                response.raise_for_status()
                payload = response.json()
        except Exception as exc:
            logger.warning("SEC filings unavailable for %s: %s", symbol_upper, exc)
            return None

        recent = payload.get("filings", {}).get("recent", {})
        forms = recent.get("form", []) or []
        dates = recent.get("filingDate", []) or []
        accessions = recent.get("accessionNumber", []) or []
        docs = recent.get("primaryDocument", []) or []
        descriptions = recent.get("primaryDocDescription", []) or []
        items = recent.get("items", []) or []

        filings = []
        for idx, form in enumerate(forms[: max(limit * 2, limit)]):
            accession = str(accessions[idx] or "")
            accession_slug = accession.replace("-", "")
            primary_doc = str(docs[idx] or "")
            archive_url = (
                f"https://www.sec.gov/Archives/edgar/data/{int(company['cik'])}/{accession_slug}/{primary_doc}"
                if accession_slug and primary_doc
                else ""
            )
            filings.append(
                {
                    "form": str(form),
                    "filed_at": str(dates[idx] or ""),
                    "description": str(descriptions[idx] or form or ""),
                    "items": str(items[idx] or ""),
                    "url": archive_url,
                    "accession_number": accession,
                }
            )

        filtered = [
            filing
            for filing in filings
            if filing["form"] in {"10-K", "10-Q", "8-K", "6-K", "20-F", "S-1", "424B2", "4"}
        ][:limit]

        return {
            "symbol": symbol_upper,
            "company_name": company["name"],
            "cik": company["cik"],
            "source": "sec",
            "filings": filtered,
            "generated_at": datetime.now(timezone.utc).isoformat(),
        }

    return await get_or_fetch(f"sec:filings:{symbol_upper}", _fetch, SEC_TTL) or {
        "symbol": symbol_upper,
        "company_name": company["name"],
        "cik": company["cik"],
        "source": "sec",
        "filings": [],
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }

